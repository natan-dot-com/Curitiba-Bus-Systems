#ifndef _READLINE_H_
#define _READLINE_H_

    #include <stdio.h>
    #include <stdlib.h>

    char *readline(FILE *stream);
    
#endif
